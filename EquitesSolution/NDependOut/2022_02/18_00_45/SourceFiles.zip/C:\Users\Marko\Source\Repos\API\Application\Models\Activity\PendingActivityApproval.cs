﻿namespace Application.Models.Activity
{
    public class PendingActivityApproval
    {
        public bool Approve { get; set; }
    }
}
