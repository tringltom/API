﻿
namespace Application.Models.User
{
    public class UserEmail
    {
        public string Email { get; set; }
    }
}
