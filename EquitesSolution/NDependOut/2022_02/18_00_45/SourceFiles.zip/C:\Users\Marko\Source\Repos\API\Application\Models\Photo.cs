﻿namespace Application.Models
{
    public class Photo
    {
        public string Id { get; set; }
        public string Url { get; set; }
    }
}
