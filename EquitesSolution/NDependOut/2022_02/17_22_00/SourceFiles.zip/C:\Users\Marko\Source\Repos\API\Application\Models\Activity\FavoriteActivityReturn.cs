﻿namespace Application.Models.Activity
{
    public class FavoriteActivityReturn
    {
        public int ActivityId { get; set; }
    }
}
