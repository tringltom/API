﻿namespace Application.Models.Activity
{
    public class FavoriteActivityBase
    {
        public int ActivityId { get; set; }
        public bool Favorite { get; set; }
    }
}
