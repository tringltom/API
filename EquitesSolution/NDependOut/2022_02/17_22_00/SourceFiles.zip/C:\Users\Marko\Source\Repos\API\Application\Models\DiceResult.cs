﻿namespace Application.Models
{
    public class DiceResult
    {
        public int Result { get; set; }
        public string Message { get; set; }
    }
}
