﻿
namespace Application.Models.User
{
    public class UserEmailVerification
    {
        public string Token { get; set; }
        public string Email { get; set; }
    }
}
