﻿namespace Infrastructure.Settings
{
    public class CloudinarySettings
    {
        public string CloudName { get; set; }
        public string APIKey { get; set; }
        public string APISecret { get; set; }
    }
}
